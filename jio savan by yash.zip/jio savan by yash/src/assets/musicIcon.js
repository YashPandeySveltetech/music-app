import React from 'react'

function MusicIcon() {
  return (
    <div>MusicIcon</div>
  )
}

export default MusicIcon