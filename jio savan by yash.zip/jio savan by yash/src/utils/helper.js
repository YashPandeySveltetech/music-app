export const checkIfLogin = () => !!localStorage.getItem("token");
