import React from 'react'

function SignUpPage() {
  return (
    <div>SignUpPage</div>
  )
}

export default SignUpPage